<?php

$servername = "localhost";
$usuario = "postgres";
$password = "12345";
$database = "GTI_Final";

?>