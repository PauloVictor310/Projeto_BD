
<footer class="footer" style="padding-top: 40px; bottom: 0; width: 100%;background-color: #80fc88; padding: 30px;">
	<div class="container text-center">
		<span class="text-muted">GTI - Gerenciamento de Times Independentes</span>
	</div>
</footer>